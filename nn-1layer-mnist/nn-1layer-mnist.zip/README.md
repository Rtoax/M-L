# Source Code Reading

## one layer neural network recognize handwriten digits
* datasets MNIST

## neural network 
*
![neural network](1layer-neural-network.png)

## lost function & accuracy
*
![loss+accuracy](loss+accuracy.jpg)